package com.chatbox.controller;

import com.chatbox.model.ChatMessage;
import com.chatbox.service.AIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.UUID;


@Controller
public class ChatController {

    @Autowired
    private AIService aiService;
    
    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    /**
     * Handles incoming chat messages and broadcasts them to all connected clients.
     * Also triggers AI response if the message mentions AI or asks for help.
     * 
     * @param chatMessage The chat message to be broadcast
     * @return The chat message with generated ID and timestamp
     */
    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/public")
    public ChatMessage sendMessage(@Payload ChatMessage chatMessage) {
        // Generate a unique ID for the message
        chatMessage.setId(UUID.randomUUID().toString());
        
        // Send AI response to every message
        sendAIResponse(chatMessage);
        
        return chatMessage;
    }

   
    @MessageMapping("/chat.addUser")
    @SendTo("/topic/public")
    public ChatMessage addUser(@Payload ChatMessage chatMessage, 
                               SimpMessageHeaderAccessor headerAccessor) {
        // Add username to web socket session
        headerAccessor.getSessionAttributes().put("username", chatMessage.getSender());
        
    
        chatMessage.setId(UUID.randomUUID().toString());
        return chatMessage;
    }

    
    /**
     * Sends an AI response to the chat.
     * 
     * @param originalMessage The original message that triggered the AI response
     */
    private void sendAIResponse(ChatMessage originalMessage) {
        try {
            // Generate AI response
            String aiResponse = aiService.generateResponse(originalMessage.getContent(), originalMessage.getSender());
            
            // Create AI message
            ChatMessage aiMessage = new ChatMessage();
            aiMessage.setId(UUID.randomUUID().toString());
            aiMessage.setContent(aiResponse);
            aiMessage.setSender("AI Assistant");
            aiMessage.setType(ChatMessage.MessageType.CHAT);
            
            // Send AI response to all clients
            messagingTemplate.convertAndSend("/topic/public", aiMessage);
            
        } catch (Exception e) {
            // Log error but don't break the chat
            System.err.println("Error generating AI response: " + e.getMessage());
        }
    }

   
    @MessageMapping("/chat.toggleAI")
    @SendTo("/topic/public")
    public ChatMessage toggleAI(@Payload ChatMessage chatMessage) {
        // Create a system message about AI toggle
        ChatMessage toggleMessage = new ChatMessage();
        toggleMessage.setId(UUID.randomUUID().toString());
        toggleMessage.setContent("AI Assistant has been " + 
            (chatMessage.getContent().equals("ON") ? "enabled" : "disabled") + " by " + chatMessage.getSender());
        toggleMessage.setSender("System");
        toggleMessage.setType(ChatMessage.MessageType.CHAT);
        
        return toggleMessage;
    }

    @GetMapping("/")
    public String chat() {
        return "chat";
    }
} 
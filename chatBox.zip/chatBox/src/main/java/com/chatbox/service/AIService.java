package com.chatbox.service;

import com.theokanning.openai.completion.chat.ChatCompletionRequest;
import com.theokanning.openai.completion.chat.ChatMessage;
import com.theokanning.openai.service.OpenAiService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.List;

/**
 * Service class for handling AI interactions using OpenAI API.
 * Provides intelligent responses to user messages.
 */
@Service
public class AIService {

    private final OpenAiService openAiService;
    private final String model = "gpt-3.5-turbo";

    public AIService(@Value("${openai.api.key:}") String apiKey) {
        // Initialize OpenAI service with API key
        if (apiKey != null && !apiKey.trim().isEmpty()) {
            this.openAiService = new OpenAiService(apiKey, Duration.ofSeconds(30));
        } else {
            this.openAiService = null;
        }
    }

    /**
     * Generates an AI response to a user message.
     * 
     * @param userMessage The message from the user
     * @param username The username of the sender
     * @return AI-generated response
     */
    public String generateResponse(String userMessage, String username) {
        // If OpenAI service is not available, use local responses
        if (openAiService == null) {
            return generateLocalResponse(userMessage, username);
        }
        
        try {
            // Create system message to define AI behavior
            ChatMessage systemMessage = new ChatMessage("system", 
                "You are a helpful AI assistant in a chat room. " +
                "Keep responses concise, friendly, and conversational. " +
                "Respond as if you're chatting with friends. " +
                "Keep responses under 100 words unless the user asks for more detail.");

            // Create user message
            ChatMessage userChatMessage = new ChatMessage("user", 
                username + " says: " + userMessage);

            // Create completion request
            ChatCompletionRequest request = ChatCompletionRequest.builder()
                .model(model)
                .messages(List.of(systemMessage, userChatMessage))
                .maxTokens(150)
                .temperature(0.7)
                .build();

            // Get response from OpenAI
            String response = openAiService.createChatCompletion(request)
                .getChoices().get(0).getMessage().getContent();

            return response.trim();

        } catch (Exception e) {
            // Return a local response if AI service fails
            return generateLocalResponse(userMessage, username);
        }
    }
    
    /**
     * Generates local responses when OpenAI is not available.
     */
    private String generateLocalResponse(String userMessage, String username) {
        String message = userMessage.toLowerCase();
        
        // Greetings
        if (message.contains("hello") || message.contains("hi") || message.contains("hey")) {
            return "Hello " + username + "! 👋 How are you doing today?";
        }
        
        // Questions about AI
        if (message.contains("ai") || message.contains("assistant") || message.contains("bot")) {
            return "Hi " + username + "! I'm your AI assistant. I can help you with questions, chat with you, or just be a friendly conversation partner! 😊";
        }
        
        // Help requests
        if (message.contains("help")) {
            return "I'm here to help, " + username + "! What can I assist you with today?";
        }
        
        // Weather
        if (message.contains("weather")) {
            return "I can't check real-time weather, " + username + ", but I hope it's a beautiful day where you are! ☀️";
        }
        
        // YouTube
        if (message.contains("youtube") || message.contains("video")) {
            return "I can't open YouTube directly, " + username + ", but here's a link you can click: <a href='https://www.youtube.com' target='_blank' style='color: #ff0000; text-decoration: underline;'>🎥 Open YouTube</a>";
        }
        
        // Google
        if (message.contains("google") || message.contains("search")) {
            return "I can't open Google directly, " + username + ", but here's a link you can click: <a href='https://www.google.com' target='_blank' style='color: #4285f4; text-decoration: underline;'>🔍 Open Google</a>";
        }
        
        // Music
        if (message.contains("music") || message.contains("spotify")) {
            return "I can't open music apps directly, " + username + ", but here are some links: <a href='https://www.spotify.com' target='_blank' style='color: #1db954; text-decoration: underline;'>🎵 Spotify</a> | <a href='https://www.youtube.com/music' target='_blank' style='color: #ff0000; text-decoration: underline;'>🎶 YouTube Music</a>";
        }
        
        // Voice commands
        if (message.contains("open") || message.contains("launch")) {
            if (message.contains("youtube")) {
                return "I can't open YouTube directly, " + username + ", but here's a link you can click: <a href='https://www.youtube.com' target='_blank' style='color: #ff0000; text-decoration: underline;'>🎥 Open YouTube</a>";
            } else if (message.contains("google")) {
                return "I can't open Google directly, " + username + ", but here's a link you can click: <a href='https://www.google.com' target='_blank' style='color: #4285f4; text-decoration: underline;'>🔍 Open Google</a>";
            } else if (message.contains("music")) {
                return "I can't open music apps directly, " + username + ", but here are some links: <a href='https://www.spotify.com' target='_blank' style='color: #1db954; text-decoration: underline;'>🎵 Spotify</a> | <a href='https://www.youtube.com/music' target='_blank' style='color: #ff0000; text-decoration: underline;'>🎶 YouTube Music</a>";
            } else {
                return "I can't open applications directly, " + username + ", but I can provide you with helpful links. What would you like to open?";
            }
        }
        
        // Jokes
        if (message.contains("joke") || message.contains("funny")) {
            return "Why don't scientists trust atoms? Because they make up everything! 😄";
        }
        
        // Time
        if (message.contains("time")) {
            return "I can't tell you the exact time, " + username + ", but I hope you're having a great moment! ⏰";
        }
        
        // Default responses
        String[] responses = {
            "That's interesting, " + username + "! Tell me more about that.",
            "Thanks for sharing, " + username + "! I'd love to hear more.",
            "Great point, " + username + "! What are your thoughts on that?",
            "I appreciate your message, " + username + "! How are you feeling today?",
            "Nice to chat with you, " + username + "! What's on your mind?",
            "Hello " + username + "! I'm here to chat and help. What would you like to talk about?",
            "Hi there, " + username + "! I'm your friendly AI assistant. How can I help you today?"
        };
        
        return responses[(int)(Math.random() * responses.length)];
    }

    /**
     * Checks if the AI service is properly configured.
     * 
     * @return true if API key is configured, false otherwise
     */
    public boolean isConfigured() {
        return openAiService != null;
    }
} 
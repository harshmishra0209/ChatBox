# ChatBox - Real-time Chat Application

A modern, real-time chat application built with Java Spring Boot and WebSocket technology. This application provides instant messaging capabilities with a beautiful, responsive user interface.

## Features

- **Real-time Messaging**: Instant message delivery using WebSocket technology
- **AI Assistant**: Intelligent responses using OpenAI GPT-3.5 (requires API key)
- **Speech Recognition**: Voice input using browser's speech recognition API
- **Text-to-Speech**: Audio output for AI responses and messages
- **Modern UI**: Beautiful, responsive design with gradient backgrounds and smooth animations
- **User Management**: Username-based chat with join/leave notifications
- **Cross-platform**: Works on desktop and mobile devices
- **No Database Required**: Simple in-memory messaging (messages are not persisted)

## Technology Stack

- **Backend**: Java 17, Spring Boot 3.2.0
- **WebSocket**: Spring WebSocket with STOMP protocol
- **AI Integration**: OpenAI GPT-3.5 API
- **Speech Recognition**: Web Speech API
- **Text-to-Speech**: Web Speech Synthesis API
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Build Tool**: Maven
- **Template Engine**: Thymeleaf

## Prerequisites

Before running this application, make sure you have the following installed:

- **Java 17** or higher
- **Maven 3.6** or higher
- **Web Browser** with WebSocket support (Chrome, Firefox, Safari, Edge)

## Installation and Setup

### 1. Clone or Download the Project

```bash
# If using git
git clone <repository-url>
cd chatBox

# Or simply download and extract the project files
```

### 2. Build the Application

```bash
# Navigate to the project directory
cd chatBox

# Clean and compile the project
mvn clean compile
```

### 3. Run the Application

```bash
# Run the Spring Boot application
mvn spring-boot:run
```

Alternatively, you can run the JAR file directly:

```bash
# Build the JAR file
mvn clean package

# Run the JAR file
java -jar target/chatbox-app-1.0.0.jar
```

### 4. Access the Application

Open your web browser and navigate to:
```
http://localhost:8080
```

## Usage

1. **Enter Username**: When you first visit the application, you'll be prompted to enter a username
2. **Join Chat**: Click "Join Chat" to enter the chat room
3. **Send Messages**: Type your message in the input field and press Enter or click the send button
4. **Voice Input**: Click the microphone button to use speech recognition for voice input
5. **AI Assistant**: Mention "AI", "help", "assistant", or "bot" in your message to get AI responses
6. **Text-to-Speech**: Click the speaker button to enable/disable audio output for AI responses
7. **Real-time Updates**: See messages from other users in real-time
8. **User Notifications**: Get notified when users join or leave the chat

## Project Structure

```
chatBox/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── chatbox/
│   │   │           ├── ChatBoxApplication.java          # Main application class
│   │   │           ├── config/
│   │   │           │   └── WebSocketConfig.java         # WebSocket configuration
│   │   │           ├── controller/
│   │   │           │   └── ChatController.java          # Chat message handling
│   │   │           └── model/
│   │   │               └── ChatMessage.java             # Message model
│   │   └── resources/
│   │       ├── templates/
│   │       │   └── chat.html                           # Main chat interface
│   │       └── application.properties                  # Application configuration
│   └── test/                                           # Test files (if any)
├── pom.xml                                             # Maven configuration
└── README.md                                           # This file
```

## Configuration

The application can be configured by modifying `src/main/resources/application.properties`:

- **Server Port**: Change `server.port` to run on a different port
- **Logging**: Adjust logging levels for debugging
- **WebSocket**: Configure message size limits
- **OpenAI API**: Add your OpenAI API key to enable AI responses (get it from https://platform.openai.com/api-keys)

### Setting up OpenAI API

1. Go to https://platform.openai.com/api-keys
2. Create a new API key
3. Add it to `src/main/resources/application.properties`:
   ```properties
   openai.api.key=your-api-key-here
   ```
4. Restart the application

**Note**: The AI assistant will only respond to messages containing "AI", "help", "assistant", or "bot".

## Development

### Adding New Features

1. **Backend Changes**: Modify Java classes in the `src/main/java/com/chatbox/` directory
2. **Frontend Changes**: Update the HTML template in `src/main/resources/templates/chat.html`
3. **Configuration**: Adjust settings in `application.properties`

### Testing

```bash
# Run tests
mvn test

# Run with coverage
mvn clean test jacoco:report
```

## Troubleshooting

### Common Issues

1. **Port Already in Use**
   - Change the port in `application.properties`: `server.port=8081`
   - Or kill the process using the current port

2. **WebSocket Connection Failed**
   - Ensure you're using a modern browser with WebSocket support
   - Check if any firewall is blocking the connection

3. **Java Version Issues**
   - Ensure you have Java 17 or higher installed
   - Check with: `java -version`

### Logs

Check the console output for detailed logs. The application logs WebSocket connections and message handling.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the [MIT License](LICENSE).

## Support

If you encounter any issues or have questions:

1. Check the troubleshooting section above
2. Review the application logs
3. Create an issue in the project repository

## Future Enhancements

Potential improvements for future versions:

- **Message Persistence**: Database storage for message history
- **Private Messaging**: Direct messaging between users
- **File Sharing**: Support for image and file uploads
- **User Authentication**: Secure login system
- **Multiple Chat Rooms**: Support for different chat channels
- **Message Encryption**: End-to-end encryption for privacy
- **Mobile App**: Native mobile applications
- **Voice/Video Chat**: Real-time audio and video communication

---

**Happy Chatting!** 🚀 